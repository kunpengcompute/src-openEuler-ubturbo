/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_KDEV_T_DEPENDS_H
#define _LINUX_KDEV_T_DEPENDS_H

#define MINORBITS	20
#define MINORMASK	((1U << MINORBITS) - 1)

/* KDEV_T */
#define MINOR(dev)	((unsigned int) ((dev) & MINORMASK))
#define MKDEV(ma, mi)	(((ma) << MINORBITS) | (mi))
#define MAJOR(dev)	((unsigned int) ((dev) >> MINORBITS))

#endif
