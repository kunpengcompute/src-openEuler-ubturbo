/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_BYTEORDER_BIG_ENDIAN_H
#define _LINUX_BYTEORDER_BIG_ENDIAN_H

#include <linux/byteorder/generic.h>

#endif /* _LINUX_BYTEORDER_BIG_ENDIAN_H */
