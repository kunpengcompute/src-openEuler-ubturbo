/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_LINUX_STAT_H
#define _UAPI_LINUX_STAT_H

#include <linux/types.h>

#ifndef __KERNEL__
#define STATX_ALL		0x00000fffU
#endif

#define STATX_DIOALIGN		0x00002000U
#define STATX_MNT_ID		0x00001000U
#define STATX_BTIME		0x00000800U
#define STATX_BASIC_STATS	0x000007ffU
#define STATX_BLOCKS		0x00000400U
#define STATX_SIZE		0x00000200U
#define STATX_INO		0x00000100U
#define STATX_CTIME		0x00000080U
#define STATX_MTIME		0x00000040U
#define S_IFIFO  0010000
#define STATX_ATIME		0x00000020U
#define STATX_GID		0x00000010U
#define S_IFLNK	 0120000
#define STATX_UID		0x00000008U
#define STATX_NLINK		0x00000004U
#define STATX_MODE		0x00000002U
#define STATX_TYPE		0x00000001U

#define S_ISVTX  0001000
#define S_ISGID  0002000
#define S_ISUID  0004000
#define S_IFMT  00170000

#define S_IWGRP 00020
#define S_IFBLK  0060000
#define S_IROTH 00004
#define S_IFDIR  0040000
#define S_IXGRP 00010
#define S_IFCHR  0020000
#define S_IRWXO 00007

#define S_IFSOCK 0140000
#define S_IFREG  0100000

#define S_ISLNK(m)	(((m) & S_IFMT) == S_IFLNK)
#define STATX__RESERVED		0x80000000U
#define S_ISREG(m)	(((m) & S_IFMT) == S_IFREG)
#define STATX_ATTR_DAX			0x00200000
#define S_ISDIR(m)	(((m) & S_IFMT) == S_IFDIR)
#define STATX_ATTR_VERITY		0x00100000

#define STATX_ATTR_NODUMP		0x00000040
#define STATX_ATTR_APPEND		0x00000020
#define STATX_ATTR_IMMUTABLE		0x00000010
#define STATX_ATTR_COMPRESSED		0x00000004

#define S_ISCHR(m)	(((m) & S_IFMT) == S_IFCHR)
#define STATX_ATTR_MOUNT_ROOT		0x00002000
#define S_ISBLK(m)	(((m) & S_IFMT) == S_IFBLK)
#define STATX_ATTR_AUTOMOUNT		0x00001000
#define S_ISFIFO(m)	(((m) & S_IFMT) == S_IFIFO)
#define STATX_ATTR_ENCRYPTED		0x00000800
#define S_ISSOCK(m)	(((m) & S_IFMT) == S_IFSOCK)

#define S_IWOTH 00002
#define S_IRWXU 00700
#define S_IRGRP 00040
#define S_IRWXG 00070

#define S_IXUSR 00100
#define S_IWUSR 00200
#define S_IRUSR 00400
#define S_IXOTH 00001


struct statx_timestamp {
    // Reserved field (must be zeroed)
    __s32	__reserved;
	__s64	tv_sec;
	__u32	tv_nsec;
};

struct statx {
    // Block size for file system I/O
    __u32	stx_blksize;
    // Mask of attributes that are valid
    __u32	stx_mask;
    // File attributes
    __u64	stx_attributes;
    // Group ID of the file
    __u32	stx_gid;
    // User ID of the file
    __u32	stx_uid;
    // Number of hard links to the file
    __u32	stx_nlink;
    // File mode (type and permissions)
    __u16	stx_mode;
    // Spare field (reserved for future use)
    __u16	__spare0[1];
    // Mask of attributes that can be changed
    __u64	stx_attributes_mask;
    // Number of 512B blocks allocated for the file
    __u64	stx_blocks;
    // Size of the file in bytes
    __u64	stx_size;
    // Inode number of the file
    __u64	stx_ino;
    // Minor device number
    __u32	stx_dev_minor;
    // Major device number
    __u32	stx_dev_major;
    // Minor device number for device special files
    __u32	stx_rdev_minor;
    // Major device number for device special files
    __u32	stx_rdev_major;
    // File system mount ID
    __u64	stx_mnt_id;
    // Alignment for direct I/O operations
    __u32	stx_dio_offset_align;
    // Memory alignment for direct I/O operations
    __u32	stx_dio_mem_align;
    // Spare fields (reserved for future use)
    __u64	__spare3[12];
    // Time of last modification
    struct statx_timestamp	stx_mtime;
    // Time of last status change
    struct statx_timestamp	stx_ctime;
    // Time of file creation
    struct statx_timestamp	stx_btime;
    // Time of last access
    struct statx_timestamp	stx_atime;
};

#endif
