// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
 * Description: SMAP Tiering Memory Solution: wrapper
 */

#include <linux/nodemask.h>
#include <linux/kprobes.h>

#include "smap_migrate_wrapper.h"

DEFINE_STATIC_KEY_FALSE(cpusets_pre_enable_key);
DEFINE_STATIC_KEY_FALSE(cpusets_enabled_key);

unsigned long (*fp_kallsyms_lookup_name)(const char *) = NULL;
int (*fp_migrate_pages)(struct list_head *from, new_folio_t get_new_folio,
			free_folio_t put_new_folio, unsigned long private,
			enum migrate_mode mode, int reason,
			unsigned int *ret_succeeded) = NULL;
void (*fp_putback_movable_pages)(struct list_head *l) = NULL;
bool (*fp_isolate_folio_to_list)(struct folio *folio,
				 struct list_head *list) = NULL;
struct hstate *(*fp_size_to_hstate)(unsigned long n) = NULL;
struct folio *(*fp_alloc_hugetlb_folio_nodemask)(
	struct hstate *h, int preferred_nid, nodemask_t *nmask, gfp_t gfp_mask,
	bool allow_alloc_fallback) = NULL;
/* 6.7+ 及部分发行版内核(如 openEuler OLK-6.6 回移)中 isolate 接口拆分为
 * folio_isolate_lru()/isolate_hugetlb()，需通过适配函数补齐旧调用方式。 */
static bool (*fp_folio_isolate_lru)(struct folio *folio) = NULL;
static bool (*fp_isolate_hugetlb)(struct folio *folio,
				  struct list_head *list) = NULL;

/*
 * 新内核中 folio_isolate_lru() 仅接收 folio，成功摘除 LRU 后由调用方
 * 自行将 folio 挂入迁移链表；hugetlb folio 仍需走 isolate_hugetlb()。
 * 该适配函数对外保持与旧 isolate_folio_to_list 一致的签名。
 */
static bool smap_isolate_folio_adapter(struct folio *folio,
				       struct list_head *list)
{
	if (folio_test_hugetlb(folio))
		return fp_isolate_hugetlb(folio, list);

	if (!fp_folio_isolate_lru(folio))
		return false;
	list_add(&folio->page.lru, list);
	return true;
}

static inline unsigned long *get_pageblock_bitmap(const struct page *p,
						  unsigned long pfn)
{
#ifdef CONFIG_SPARSEMEM
	return section_to_usemap(__pfn_to_section(pfn));
#else
	return page_zone(p)->pageblock_flags;
#endif
}

void lookup_kallsyms_lookup_name(void)
{
	struct kprobe kp;
	memset(&kp, 0, sizeof(struct kprobe));
	kp.symbol_name = "kallsyms_lookup_name";
	if (register_kprobe(&kp) < 0) {
		return;
	}
	fp_kallsyms_lookup_name = (unsigned long (*)(const char *))kp.addr;
	unregister_kprobe(&kp);
}

int smap_process_symbols(void)
{
	lookup_kallsyms_lookup_name();
	if (!fp_kallsyms_lookup_name)
		return -EFAULT;

	// clang-format off
	fp_migrate_pages =
		(int (*)(struct list_head *from, new_folio_t get_new_folio,
			 free_folio_t put_new_folio, unsigned long private,
			 enum migrate_mode mode, int reason,
			 unsigned int *ret_succeeded))
			fp_kallsyms_lookup_name("migrate_pages");
	fp_putback_movable_pages =
		(void (*)(struct list_head *l))
			fp_kallsyms_lookup_name("putback_movable_pages");
	/* isolate 接口随内核版本命名不同，按以下顺序兼容：
	 * 6.2+ : isolate_folio_to_list(struct folio *, struct list_head *)
	 * 6.1  : isolate_lru_folio(struct folio *, struct list_head *)
	 * 6.7+ / openEuler OLK-6.6 回移 :
	 *       folio_isolate_lru(struct folio *) + isolate_hugetlb() */
	fp_isolate_folio_to_list =
		(bool (*)(struct folio *folio, struct list_head *list))
			fp_kallsyms_lookup_name("isolate_folio_to_list");
	if (!fp_isolate_folio_to_list)
		fp_isolate_folio_to_list =
			(bool (*)(struct folio *folio, struct list_head *list))
				fp_kallsyms_lookup_name("isolate_lru_folio");
	if (!fp_isolate_folio_to_list) {
		fp_isolate_hugetlb =
			(bool (*)(struct folio *folio, struct list_head *list))
				fp_kallsyms_lookup_name("isolate_hugetlb");
		fp_folio_isolate_lru =
			(bool (*)(struct folio *folio))
				fp_kallsyms_lookup_name("folio_isolate_lru");
		if (fp_isolate_hugetlb && fp_folio_isolate_lru)
			fp_isolate_folio_to_list = smap_isolate_folio_adapter;
	}
	fp_size_to_hstate =
		(struct hstate *(*)(unsigned long))
			fp_kallsyms_lookup_name("size_to_hstate");
	fp_alloc_hugetlb_folio_nodemask =
		(struct folio *(*)(struct hstate *, int, nodemask_t *, gfp_t,
				   bool))
			fp_kallsyms_lookup_name("alloc_hugetlb_folio_nodemask");
	// clang-format on
	if (!(fp_migrate_pages && fp_putback_movable_pages &&
	      fp_isolate_folio_to_list && fp_size_to_hstate &&
	      fp_alloc_hugetlb_folio_nodemask)) {
		pr_err("failed to resolve kernel symbols: migrate_pages=%p, "
		       "putback_movable_pages=%p, "
		       "isolate_folio_to_list/isolate_lru_folio/"
		       "(isolate_hugetlb+folio_isolate_lru)=%p, "
		       "size_to_hstate=%p, alloc_hugetlb_folio_nodemask=%p\n",
		       fp_migrate_pages, fp_putback_movable_pages,
		       fp_isolate_folio_to_list, fp_size_to_hstate,
		       fp_alloc_hugetlb_folio_nodemask);
		return -EFAULT;
	}

	return 0;
}

static inline unsigned long pfn_to_bitidx(const struct page *p,
					  unsigned long pfn)
{
#ifdef CONFIG_SPARSEMEM
	pfn &= (PAGES_PER_SECTION - 1);
#else
	pfn = pfn -
	      round_down(page_zone(p)->zone_start_pfn, pageblock_nr_pages);
#endif
	return (pfn >> pageblock_order) * NR_PAGEBLOCK_BITS;
}

static __always_inline unsigned long
__get_pfnblock_flags_mask(const struct page *page, unsigned long pfn,
			  unsigned long mask)
{
	unsigned long bitidx, word_bitidx;
	unsigned long *bitmap = get_pageblock_bitmap(page, pfn);
	bitidx = pfn_to_bitidx(page, pfn);
	word_bitidx = bitidx / BITS_PER_LONG;
	bitidx &= (BITS_PER_LONG - 1);

	return (bitmap[word_bitidx] >> bitidx) & mask;
}

unsigned long get_pfnblock_flags_mask(const struct page *page,
				      unsigned long pfn, unsigned long mask)
{
	return __get_pfnblock_flags_mask(page, pfn, mask);
}
